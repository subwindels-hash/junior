<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-18 00:04:08 --> csrf: rejected / from 141.11.243.210 (token absent)
ERROR - 2026-11-18 00:04:17 --> csrf: rejected / from 141.11.243.210 (token absent)
ERROR - 2026-11-18 19:46:57 --> csrf: rejected /graphql from 190.229.213.243 (token absent)
ERROR - 2026-11-18 19:46:58 --> csrf: rejected /api/graphql from 190.229.213.243 (token absent)
ERROR - 2026-11-18 19:46:58 --> csrf: rejected /graphql from 190.229.213.243 (token absent)
ERROR - 2026-11-18 19:46:59 --> csrf: rejected /api/graphql from 190.229.213.243 (token absent)
ERROR - 2026-11-18 19:46:59 --> csrf: rejected /wp-admin/admin-ajax.php from 41.135.205.92 (token absent)
ERROR - 2026-11-18 19:46:59 --> csrf: rejected /wp-admin/admin-ajax.php from 41.135.205.92 (token absent)
