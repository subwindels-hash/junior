<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-25 05:26:54 --> csrf: rejected /xmlrpc.php from 152.56.0.30 (token absent)
ERROR - 2026-11-25 12:25:02 --> csrf: rejected /xmlrpc.php from 181.142.223.236 (token absent)
ERROR - 2026-11-25 13:31:06 --> csrf: rejected /xmlrpc.php from 103.188.218.220 (token absent)
ERROR - 2026-11-25 13:53:21 --> csrf: rejected /xmlrpc.php from 49.15.121.31 (token absent)
