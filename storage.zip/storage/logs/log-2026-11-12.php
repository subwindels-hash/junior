<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-12 16:37:06 --> Severity: Warning --> Undefined property: stdClass::$provider_public_id /home2/macti1ea/public_html/application/libraries/SmmServiceAdminService.php 83
ERROR - 2026-11-12 19:44:33 --> csrf: rejected /graphql from 186.33.28.71 (token absent)
ERROR - 2026-11-12 19:44:33 --> csrf: rejected /api/graphql from 186.33.28.71 (token absent)
ERROR - 2026-11-12 19:44:33 --> csrf: rejected /graphql from 186.33.28.71 (token absent)
ERROR - 2026-11-12 19:44:33 --> csrf: rejected /api/graphql from 186.33.28.71 (token absent)
ERROR - 2026-11-12 19:44:34 --> csrf: rejected /wp-admin/admin-ajax.php from 38.7.23.20 (token absent)
ERROR - 2026-11-12 19:44:35 --> csrf: rejected /wp-admin/admin-ajax.php from 38.7.23.20 (token absent)
ERROR - 2026-11-12 22:59:47 --> permission denied: ADMIN lacks orders.view
ERROR - 2026-11-12 23:00:00 --> Severity: Warning --> Undefined property: stdClass::$provider_public_id /home2/macti1ea/public_html/application/libraries/SmmServiceAdminService.php 83
