<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-20 00:52:02 --> csrf: rejected / from 43.130.104.85 (token absent)
ERROR - 2026-11-20 00:52:02 --> csrf: rejected / from 43.130.104.85 (token absent)
ERROR - 2026-11-20 00:52:02 --> csrf: rejected / from 43.130.104.85 (token absent)
ERROR - 2026-11-20 09:46:27 --> csrf: rejected / from 45.32.123.21 (token absent)
