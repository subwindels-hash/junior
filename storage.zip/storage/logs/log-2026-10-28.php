<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-10-28 16:13:42 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:13:42 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 16:13:42 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 16:13:42 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 16:13:42 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 16:13:42 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 16:13:42'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 16:13:42'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 16:13:42 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:14 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:14 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 16:14:14'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 16:14:14'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 16:14:14 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:19 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:19 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:19 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 16:14:19 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 16:14:19'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 16:14:19'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 16:14:19 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:23 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:23 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 16:14:23 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 16:14:23 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 16:14:23'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 16:14:23'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 16:14:23 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:28 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:28 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 16:14:28 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 16:14:31 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:31 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 16:14:31 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 16:14:33 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:33 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 16:14:33 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 16:14:36 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:40 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:40 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 16:14:40'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 16:14:40'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 16:14:40 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:48 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:48 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 16:14:48 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 16:14:48 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:48 --> Query error: Table 'halymumm_smm.blog_posts' doesn't exist - Invalid query: SELECT *
FROM `blog_posts`
WHERE `status` = 'PUBLISHED'
AND `published_at` <= '2026-10-28 16:14:48'
ORDER BY `published_at` DESC
 LIMIT 9
ERROR - 2026-10-28 16:14:48 --> Severity: error --> Exception: Call to a member function result() on false /home/halymumm/try.vortexprecisionit.com/application/models/Blog_post_model.php 19
ERROR - 2026-10-28 16:14:52 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:52 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:52 --> Query error: Table 'halymumm_smm.blog_posts' doesn't exist - Invalid query: SELECT *
FROM `blog_posts`
WHERE `status` = 'PUBLISHED'
AND `published_at` <= '2026-10-28 16:14:52'
ORDER BY `published_at` DESC
 LIMIT 9
ERROR - 2026-10-28 16:14:52 --> Severity: error --> Exception: Call to a member function result() on false /home/halymumm/try.vortexprecisionit.com/application/models/Blog_post_model.php 19
ERROR - 2026-10-28 16:14:54 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:54 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 16:14:54 --> Query error: Table 'halymumm_smm.blog_posts' doesn't exist - Invalid query: SELECT *
FROM `blog_posts`
WHERE `status` = 'PUBLISHED'
AND `published_at` <= '2026-10-28 16:14:54'
ORDER BY `published_at` DESC
 LIMIT 9
ERROR - 2026-10-28 16:14:54 --> Severity: error --> Exception: Call to a member function result() on false /home/halymumm/try.vortexprecisionit.com/application/models/Blog_post_model.php 19
ERROR - 2026-10-28 16:14:56 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:21:25 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:21:25 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:21:25 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:21:25 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:21:25'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:21:25'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:21:25 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:21:39 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:21:39 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:21:39'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:21:39'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:21:39 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:21:44 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:21:44 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:21:44 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:21:44 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:21:44'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:21:44'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:21:44 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:22:05 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:22:05 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 19:22:05 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:22:05'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:22:05'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:22:05 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:22:38 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:22:38 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:22:38 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:22:38 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:22:38 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:22:38 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:22:38'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:22:38'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:22:38 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:23:10 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:23:10'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:23:10'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:23:10 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:23:10'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:23:10'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:23:10 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:32:58 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:32:58 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:32:58 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:32:59 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:32:59 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 19:32:59 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:32:59'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:32:59'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:32:59 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:33:13 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:33:13 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 19:33:13 --> Query error: Table 'halymumm_smm.blacklisted_ips' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `blacklisted_ips`
WHERE `ip` = '154.120.117.243'
ERROR - 2026-10-28 19:33:13 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:33:20 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:33:20 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 19:33:20 --> Query error: Table 'halymumm_smm.blacklisted_ips' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `blacklisted_ips`
WHERE `ip` = '154.120.117.243'
ERROR - 2026-10-28 19:33:20 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:33:24 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:33:24 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 19:33:24 --> Query error: Table 'halymumm_smm.blacklisted_ips' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `blacklisted_ips`
WHERE `ip` = '154.120.117.243'
ERROR - 2026-10-28 19:33:24 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:33:28 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:33:28 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 19:33:28 --> Query error: Table 'halymumm_smm.blacklisted_ips' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `blacklisted_ips`
WHERE `ip` = '154.120.117.243'
ERROR - 2026-10-28 19:33:28 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:33:33 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:33:33 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 19:33:33 --> Query error: Table 'halymumm_smm.blacklisted_ips' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `blacklisted_ips`
WHERE `ip` = '154.120.117.243'
ERROR - 2026-10-28 19:33:33 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:33:56 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:33:56 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:33:56 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:33:56 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:33:56'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:33:56'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:33:56 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:35:52 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:35:52 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:35:52 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:35:52 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:35:52'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:35:52'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:35:52 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:36:23 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:36:23 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:36:23'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:36:23'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:36:23 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:41:28 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:41:28 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:41:28 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:41:28 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:41:28 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:41:28 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:41:28'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:41:28'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:41:28 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:42:50 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:42:50 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:42:50 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:42:50 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 19:42:50 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:42:53 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:42:53 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 19:42:53 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:42:56 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:42:57 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:42:57 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:42:57'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:42:57'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:42:57 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:01 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:01 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:43:01 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:43:01 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:43:01'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:43:01'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:43:01 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:06 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:06 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:06 --> Query error: Table 'halymumm_smm.marketplace_listings' doesn't exist - Invalid query: SELECT marketplace_listings.*
FROM `marketplace_listings`
WHERE `status` = 'ACTIVE'
AND (marketplace_listings.product_type <> 'PHYSICAL' OR EXISTS (SELECT 1 FROM physical_products WHERE physical_products.listing_id = marketplace_listings.id AND physical_products.sku <> ''))
ORDER BY `marketplace_listings`.`created_at` DESC
 LIMIT 24
ERROR - 2026-10-28 19:43:06 --> Severity: error --> Exception: Call to a member function result() on false /home/halymumm/try.vortexprecisionit.com/application/models/Marketplace_listing_model.php 32
ERROR - 2026-10-28 19:43:08 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:12 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:12 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:43:12'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:43:12'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:43:12 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:16 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:16 --> Query error: Table 'halymumm_smm.faqs' doesn't exist - Invalid query: SELECT *
FROM `faqs`
WHERE `is_active` = 1
ORDER BY `sorting` ASC, `id` ASC
ERROR - 2026-10-28 19:43:16 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:43:16'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:43:16'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:43:16 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:18 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:43:18 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:43:18'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:43:18'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:43:18 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:44:16 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:44:16 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:44:16 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:44:16 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:44:16 --> Query error: Table 'halymumm_smm.marketplace_listings' doesn't exist - Invalid query: SELECT marketplace_listings.*
FROM `marketplace_listings`
WHERE `status` = 'ACTIVE'
AND (marketplace_listings.product_type <> 'PHYSICAL' OR EXISTS (SELECT 1 FROM physical_products WHERE physical_products.listing_id = marketplace_listings.id AND physical_products.sku <> ''))
ORDER BY `marketplace_listings`.`created_at` DESC
 LIMIT 24
ERROR - 2026-10-28 19:44:16 --> Severity: error --> Exception: Call to a member function result() on false /home/halymumm/try.vortexprecisionit.com/application/models/Marketplace_listing_model.php 32
ERROR - 2026-10-28 19:54:57 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:54:57 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:54:57 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:54:57 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:54:57 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:54:57 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:54:57'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:54:57'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:54:57 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:55:00 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:55:00 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:55:00 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:55:00 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:55:00'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:55:00'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:55:00 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:22 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:22 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:56:22 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:56:22 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:56:22'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:56:22'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:56:22 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:23 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:23 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 19:56:23 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:56:23 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:23 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 19:56:23 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:56:30 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:30 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:56:30 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:56:30 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:56:30'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:56:30'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:56:30 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:31 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:31 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 19:56:31 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:56:33 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:33 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:56:33 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:56:33 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:56:33'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:56:33'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:56:33 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:37 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:37 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:56:37 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:56:37 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:56:37'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:56:37'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:56:37 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:47 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:47 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:56:47 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:56:47 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:56:47'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:56:47'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:56:47 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:50 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:50 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 19:56:50 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 19:56:54 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:56:54 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 19:56:54 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 19:56:54 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:56:54'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:56:54'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:56:54 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:58:06 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 19:58:06 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 19:58:06 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 19:58:06 --> Query error: Table 'halymumm_smm.faqs' doesn't exist - Invalid query: SELECT *
FROM `faqs`
WHERE `is_active` = 1
ORDER BY `sorting` ASC, `id` ASC
ERROR - 2026-10-28 19:58:06 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 19:58:06'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 19:58:06'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 19:58:06 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:00:43 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:00:43 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 20:00:43 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 20:00:43 --> Query error: Table 'halymumm_smm.faqs' doesn't exist - Invalid query: SELECT *
FROM `faqs`
WHERE `is_active` = 1
ORDER BY `sorting` ASC, `id` ASC
ERROR - 2026-10-28 20:00:43 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 20:00:43'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 20:00:43'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 20:00:43 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:00:53 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:00:53 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 20:00:53'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 20:00:53'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 20:00:53 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:01:15 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:01:15 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 20:01:15 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 20:01:15 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 20:01:15'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 20:01:15'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 20:01:15 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:01:24 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:01:24 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 20:01:24 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 20:01:27 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:01:27 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 20:01:27 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 20:01:27 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 20:01:27'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 20:01:27'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 20:01:27 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:37:29 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:37:29 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 20:37:29 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 20:37:29 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 20:37:29 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 20:37:29 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 20:37:29'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 20:37:29'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 20:37:29 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:51:53 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:51:53 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 20:51:53 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 20:51:53 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `services`
LEFT JOIN `service_categories` ON `service_categories`.`id` = `services`.`category_id`
WHERE `services`.`status` = 'ACTIVE'
ERROR - 2026-10-28 20:51:53 --> Severity: error --> Exception: Call to a member function num_rows() on false /home/halymumm/try.vortexprecisionit.com/system/database/DB_query_builder.php 1430
ERROR - 2026-10-28 20:51:57 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 20:51:57 --> Query error: Table 'halymumm_smm.services' doesn't exist - Invalid query: SELECT s.public_id, s.name, s.slug, s.rate, s.min_quantity, s.max_quantity, s.average_time, s.refill_supported, s.cancel_supported, s.dripfeed_supported, c.name AS category_name, c.slug AS category_slug
FROM `services` `s`
LEFT JOIN `service_categories` `c` ON `c`.`id` = `s`.`category_id`
WHERE `s`.`status` = 'ACTIVE'
ORDER BY `s`.`featured` DESC, `s`.`sorting` ASC
 LIMIT 6
ERROR - 2026-10-28 20:51:57 --> homepage catalogue unavailable: Call to a member function result() on false
ERROR - 2026-10-28 20:51:57 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 20:51:57'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 20:51:57'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 20:51:57 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 21:10:59 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 21:10:59 --> Query error: Table 'halymumm_smm.job_runs' doesn't exist - Invalid query: SELECT *
FROM `job_runs`
ORDER BY `started_at` DESC
 LIMIT 400
ERROR - 2026-10-28 21:10:59 --> cron autotick due-check failed: Call to a member function result() on false
ERROR - 2026-10-28 21:10:59 --> Query error: Table 'halymumm_smm.users' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users`
WHERE `role` = 'SUPER_ADMIN'
AND `status` = 'ACTIVE'
ERROR - 2026-10-28 21:10:59 --> Query error: Table 'halymumm_smm.announcements' doesn't exist - Invalid query: SELECT *
FROM `announcements`
WHERE `is_active` = 1
AND   (
starts_at IS NULL
OR `starts_at` <= '2026-10-28 21:10:59'
 )
AND   (
ends_at IS NULL
OR `ends_at` >= '2026-10-28 21:10:59'
 )
ORDER BY `severity` DESC, `created_at` DESC
ERROR - 2026-10-28 21:10:59 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 21:11:04 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
ERROR - 2026-10-28 21:11:04 --> Query error: Table 'halymumm_smm.feature_flags' doesn't exist - Invalid query: SELECT *
FROM `feature_flags`
