<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-27 05:32:18 --> health: redis check failed: Connection refused
ERROR - 2026-11-27 05:32:47 --> health: redis check failed: Connection refused
ERROR - 2026-11-27 05:45:19 --> 404: GET /shop/product/1
ERROR - 2026-11-27 05:45:19 --> 404 Page Not Found: 
ERROR - 2026-11-27 05:45:22 --> health: redis check failed: Connection refused
ERROR - 2026-11-27 20:22:52 --> SecureHttpClient retry 0 GET https://bestdatanig.com.ng/api/user/ error=Operation timed out after 15001 milliseconds with 0 bytes received rid=4fc221e11cb2cbab
ERROR - 2026-11-27 20:23:08 --> SecureHttpClient retry 1 GET https://bestdatanig.com.ng/api/user/ error=Operation timed out after 15001 milliseconds with 0 bytes received rid=4fc221e11cb2cbab
ERROR - 2026-11-27 20:23:24 --> SecureHttpClient retry 2 GET https://bestdatanig.com.ng/api/user/ error=Operation timed out after 15001 milliseconds with 0 bytes received rid=4fc221e11cb2cbab
