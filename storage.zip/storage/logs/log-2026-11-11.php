<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-11 02:46:54 --> csrf: rejected /wp-admin/admin-ajax.php from 180.191.124.232 (token absent)
ERROR - 2026-11-11 02:46:55 --> csrf: rejected /graphql from 105.104.167.233 (token absent)
ERROR - 2026-11-11 02:46:55 --> csrf: rejected /wp-admin/admin-ajax.php from 180.191.124.232 (token absent)
ERROR - 2026-11-11 02:46:56 --> csrf: rejected /api/graphql from 105.104.167.233 (token absent)
ERROR - 2026-11-11 02:46:57 --> csrf: rejected /graphql from 105.104.167.233 (token absent)
ERROR - 2026-11-11 02:46:57 --> csrf: rejected /api/graphql from 105.104.167.233 (token absent)
ERROR - 2026-11-11 02:47:08 --> csrf: rejected /xmlrpc.php from 181.78.21.43 (token absent)
