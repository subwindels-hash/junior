<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-23 07:26:01 --> inbox poll failed: mailbox connection closed during PASS
ERROR - 2026-11-23 13:13:58 --> csrf: rejected /graphql from 95.139.191.153 (token absent)
ERROR - 2026-11-23 13:14:02 --> csrf: rejected /api/graphql from 95.139.191.153 (token absent)
ERROR - 2026-11-23 13:14:03 --> csrf: rejected /graphql from 95.139.191.153 (token absent)
ERROR - 2026-11-23 13:14:05 --> csrf: rejected /api/graphql from 95.139.191.153 (token absent)
ERROR - 2026-11-23 13:14:07 --> csrf: rejected /wp-admin/admin-ajax.php from 154.21.22.21 (token absent)
ERROR - 2026-11-23 13:14:09 --> csrf: rejected /wp-admin/admin-ajax.php from 154.21.22.21 (token absent)
