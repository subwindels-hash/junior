<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-07 13:34:11 --> csrf: rejected /admin/providers/dd08ec7eecc73df765845d381a/sync from 102.91.5.237 (token absent)
