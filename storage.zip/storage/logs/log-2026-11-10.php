<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-10 09:39:19 --> csrf: rejected /admin/login from 102.91.102.77 (token absent)
ERROR - 2026-11-10 13:52:14 --> csrf: rejected /logout from 102.91.77.178 (token absent)
