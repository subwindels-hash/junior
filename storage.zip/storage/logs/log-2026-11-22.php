<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-22 00:04:55 --> csrf: rejected /register from 149.102.234.50 (token absent)
ERROR - 2026-11-22 01:56:17 --> csrf: rejected /wp-admin/admin-ajax.php from 37.61.122.88 (token absent)
ERROR - 2026-11-22 01:56:18 --> csrf: rejected /wp-admin/admin-ajax.php from 37.61.122.88 (token absent)
ERROR - 2026-11-22 01:56:18 --> csrf: rejected /graphql from 37.61.122.88 (token absent)
ERROR - 2026-11-22 01:56:18 --> csrf: rejected /api/graphql from 37.61.122.88 (token absent)
ERROR - 2026-11-22 01:56:19 --> csrf: rejected /graphql from 37.61.122.88 (token absent)
ERROR - 2026-11-22 01:56:19 --> csrf: rejected /api/graphql from 37.61.122.88 (token absent)
ERROR - 2026-11-22 01:56:23 --> csrf: rejected /xmlrpc.php from 192.140.114.58 (token absent)
ERROR - 2026-11-22 04:08:08 --> csrf: rejected /graphql from 191.101.239.27 (token absent)
ERROR - 2026-11-22 04:08:08 --> csrf: rejected /api/graphql from 191.101.239.27 (token absent)
