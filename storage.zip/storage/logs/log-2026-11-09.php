<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-09 05:16:46 --> csrf: rejected / from 52.159.237.9 (token absent)
ERROR - 2026-11-09 09:44:06 --> csrf: rejected /xmlrpc.php from 157.35.96.90 (token absent)
