<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-08 07:17:56 --> csrf: rejected / from 64.16.177.98 (token absent)
ERROR - 2026-11-08 07:17:57 --> csrf: rejected / from 64.16.177.98 (token absent)
