<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-24 08:07:06 --> SecureHttpClient retry 0 GET https://bestdatanig.com.ng/api/user/ error=Operation timed out after 15001 milliseconds with 0 bytes received rid=e3e7997458498f57
ERROR - 2026-11-24 08:07:21 --> SecureHttpClient retry 1 GET https://bestdatanig.com.ng/api/user/ error=Operation timed out after 15001 milliseconds with 0 bytes received rid=e3e7997458498f57
ERROR - 2026-11-24 08:07:38 --> SecureHttpClient retry 2 GET https://bestdatanig.com.ng/api/user/ error=Operation timed out after 15001 milliseconds with 0 bytes received rid=e3e7997458498f57
ERROR - 2026-11-24 09:14:04 --> SecureHttpClient retry 0 GET https://bestdatanig.com.ng/api/user/ error=Operation timed out after 15001 milliseconds with 0 bytes received rid=2a5bdf30554f2626
