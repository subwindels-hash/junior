<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-17 10:15:39 --> csrf: rejected /wp-json/lazy-blocks/v1/block-constructor-preview/ from 107.189.14.87 (token absent)
ERROR - 2026-11-17 10:15:39 --> csrf: rejected /?rest_route=/lazy-blocks/v1/block-constructor-preview/ from 107.189.14.87 (token absent)
