<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-11-16 03:41:45 --> csrf: rejected /wp-admin/admin-ajax.php from 181.118.57.55 (token absent)
ERROR - 2026-11-16 03:41:48 --> csrf: rejected /wp-admin/admin-ajax.php from 181.118.57.55 (token absent)
ERROR - 2026-11-16 03:42:00 --> csrf: rejected /graphql from 168.90.127.234 (token absent)
ERROR - 2026-11-16 03:42:01 --> csrf: rejected /api/graphql from 168.90.127.234 (token absent)
ERROR - 2026-11-16 03:42:03 --> csrf: rejected /graphql from 103.111.226.239 (token absent)
ERROR - 2026-11-16 03:42:05 --> csrf: rejected /api/graphql from 103.111.226.239 (token absent)
