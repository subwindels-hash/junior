# Dev database and dev application server

**These tools are for local development and automated testing only.** They are
not part of a deployment, are never loaded by the application, and are excluded
from the production package. Production runs PHP-FPM behind Nginx against MySQL
8 / MariaDB, exactly as `docker/` and `INSTALLATION.md` describe.

## Why they exist

Active Digital Hub targets MySQL, and the application, migrations and mysqli/PDO
drivers are written for it. In an environment where no MySQL server and no PHP
runtime can be installed, the alternatives are to test nothing or to test
something that is not the real application. Neither is acceptable for a payment
system, so these tools let the **unmodified** application run end to end:

| Tool | What it is |
| --- | --- |
| `tools/devdb/server.js` | A MySQL wire-protocol server backed by SQLite. Real handshake, real COM_QUERY, real result sets and error codes, so CodeIgniter's driver connects to it without knowing the difference. |
| `tools/devdb/translate.js` | MySQL → SQLite SQL translation for the dialect this repository actually uses. |
| `tools/devdb/protocol.js` | Wire-protocol codec (packets, capability flags, status flags). |
| `tools/devserver/server.mjs` | Serves the real CodeIgniter application over HTTP. |
| `tools/devserver/*_check.mjs` | End-to-end tests driven over real HTTP with cookies and CSRF. |

## Running it

```bash
node tools/devdb/server.js --port 3399 --db storage/devdb/marvy.sqlite --fresh
node tools/devserver/server.mjs --port 8080
```

Point `.env` at the dev database:

```
VP_DB_DSN=mysql:host=127.0.0.1;port=3399;dbname=marvysocials;charset=utf8mb4
VP_DB_DRIVER=pdo
VP_DB_STRICT=inherit
```

Then migrate and seed exactly as production would:

```bash
php index.php migrate
php index.php seed core
php index.php seed demo
```

Neither seed creates a staff account, so the end-to-end check scripts (which
sign in as username `admin`) need one first. With `VP_SETUP_TOKEN` set in
`.env`, open `http://127.0.0.1:8080/setup` and create the first administrator
with **username `admin`** and the password you intend to pass as
`--admin-password` / `DEMO_PASSWORD`.

## Browser authentication regression

With a **disposable empty imported database** and a configured `VP_SETUP_TOKEN`,
run the real application server and use an installed Chromium executable:

```bash
BASE_URL=http://127.0.0.1:8081 VP_SETUP_TOKEN='your-disposable-setup-token' \
  CHROMIUM_PATH=/path/to/chromium node tools/devserver/auth_browser_check.mjs
```

This creates test accounts and the first admin; never run it against a live
installation. It checks actual mouse/touch-sized browser hit targets as well as
HTTP, sessions and role restrictions. The SQLite-backed devdb does not model
MySQL named locks, so production locking and concurrent claims must also be
verified against a real MySQL/MariaDB server.

For a real MySQL race test, import the production SQL into an empty local
`auth_race_*` database and run two independent PHP application workers pointing
to that same database with the same setup token. Then run:

```bash
AUTH_RACE_DISPOSABLE=1 AUTH_RACE_DB=auth_race_test AUTH_RACE_USER=panel \
  AUTH_RACE_PASSWORD='local-test-password' AUTH_RACE_DB_PORT=3306 \
  VP_SETUP_TOKEN='your-disposable-setup-token' \
  AUTH_RACE_WORKER_A=http://127.0.0.1:8086 AUTH_RACE_WORKER_B=http://127.0.0.1:8087 \
  node tools/devserver/bootstrap_race_check.mjs
```

This creates an administrator and must only be used with a disposable database.
The database user must be able to see its own connections in `SHOW PROCESSLIST`.

## Editing PHP while the dev server runs

The wasm runtime keeps compiled PHP per worker, so **restart
`tools/devserver/server.mjs` after changing any `.php` file** — otherwise the
running workers keep serving the previous version and you will debug a file
that is not the one being executed.

## The test scripts

```bash
node tools/devserver/smoke.mjs                                  # every public route
node tools/devserver/journey.mjs      --admin-password <pw>     # customer + admin walkthrough
node tools/devserver/admin_check.mjs  --admin-password <pw>     # settings, secrets, impersonation
node tools/devserver/commerce_check.mjs --admin-password <pw>   # deposit, approval, order, ticket
node tools/devserver/content_check.mjs  --admin-password <pw>   # CMS round trip + XSS sanitising
node tools/devserver/pin_check.mjs                              # security PIN lifecycle
node tools/devserver/blockonomics_check.mjs                     # BTC callback handling
node tools/devserver/responsive_check.mjs                       # layout audit
node tools/devserver/gateway_check.mjs        --admin-password <pw>   # hosted gateway config + signed webhook
node tools/devserver/reconciliation_check.mjs                   # deposits whose callback never arrived
node tools/devserver/notifications_check.mjs  --admin-password <pw>   # inbox, email queue, preferences
node tools/devserver/smm_provider_check.mjs                     # real SMM adapter against a fake panel
node tools/devserver/page_audit.mjs           --password <pw>   # every dashboard/admin page
node tools/devserver/link_crawl.mjs           --password <pw>   # follow every internal link
node tools/devserver/image_audit.mjs          --password <pw>   # every <img> resolves
node tools/devserver/api_check.mjs            --password <pw>   # reseller API: envelope, scopes, idempotency
node tools/devserver/refunds_check.mjs        --admin-password <pw>   # refills, partial refunds, refused cancellations
node tools/devserver/analytics_check.mjs      --admin-password <pw>   # every reported figure vs the database
node tools/devserver/service_recovery_check.mjs --admin-password <pw> # stuck VTU/number/identity/giftcard purchases
node tools/devserver/security_check.mjs       --admin-password <pw>   # IDOR, CSRF, privilege escalation, live RBAC matrix
node tools/devserver/support_check.mjs        --admin-password <pw>   # assistant limits, ticket attachments
node tools/devserver/marketplace_fulfilment_check.mjs --admin-password <pw> # escrow, refunds, download revocation
node tools/devserver/physical_product_check.mjs --admin-password <pw>      # SKU/package details and physical-listing validation
node tools/devserver/physical_shipping_check.mjs --password <pw> --admin-password <pw> # browser checkout, carrier quote, shipment delivery
node tools/devserver/physical_order_refund_check.mjs --admin-password <pw> # shipment-screen refund and audit trail
node tools/devserver/seed_load.mjs                              # a year of trading, for measurement (--clean removes it)
node tools/devserver/perf_check.mjs           --admin-password <pw>   # query cost of every heavy screen under that load
node tools/devserver/deployment_check.mjs                       # extract the zip, import the SQL, boot it, sign in
node tools/devserver/pricing_check.mjs        --admin-password <pw>   # coupon limits, minimum spend, batched pricing
node tools/devserver/chrome_check.mjs         --admin-password <pw>   # one menu everywhere, navy chrome, announcement, cron screen, contact map
node tools/devserver/attachment_check.mjs     --admin-password <pw>   # who may read a support attachment: owner, stranger, staff, internal note
node tools/devserver/legal_check.mjs          --admin-password <pw>   # the operator's legal identity on Terms, Privacy and the footer
node tools/devdb/import_sql.cjs --port 3410 --file database/marvysocials.sql  # apply a dump over the wire
```

`smm_provider_check.mjs` and `refunds_check.mjs` stand up
`tools/devserver/fake_smm_panel.mjs` on localhost and need
`HTTP_ALLOW_PRIVATE_HOSTS=true` in `.env` — `SecureHttpClient` refuses
non-public hosts by default (SSRF protection). Never set that in production.

## One command for all of it

```bash
bash tools/verify_all.sh --admin-password '<demo password>'             # everything
bash tools/verify_all.sh --admin-password '<demo password>' --with-load # + performance
bash tools/verify_all.sh --unit-only                                    # no server needed
```

It runs the static checks, the PHP suite, the packaging, every end-to-end
check, the fresh-deployment simulation and (with `--with-load`) the performance
measurement, and exits with the number of failed stages.

Start the application server with `--max-requests 300`. Each wasm runtime leaks
a few file descriptors per request; after a few hundred the process answers 500
to everything, which looks exactly like the application breaking. The flag
recycles the PHP pool the way PHP-FPM's `pm.max_requests` does.

If a check that uses the fake provider panel fails with "Incorrect API key",
an abandoned panel from an earlier run is still holding the port:
`pkill -f fake_smm_panel`. Both checks now refuse to start in that state rather
than testing somebody else's process.

## Measuring query cost

Start the database with a stats side-channel and the number of statements each
page issues can be read from outside the application:

```bash
node tools/devdb/server.js --port 3399 --stats-port 3400 --db storage/devdb/marvy.sqlite
curl -X POST localhost:3400/reset && curl -s localhost:3400/    # { queries, byTable, slowest, samples }
```

That is what `perf_check.mjs` uses. An N+1 is invisible in a functional test and
obvious here.

## What this does and does not prove

**Does prove:** the application's own logic — routing, auth, sessions, CSRF,
RBAC, the order state machine, the double-entry ledger, webhook verification
and idempotency, admin controls, and that content saved in the back office
reaches the public site.

**Does not prove:** that MySQL behaves identically to the SQLite translation in
every edge case, or that any third-party API (providers, gateways, SMTP) responds
as documented. Those need a real MySQL instance and real credentials. CI runs the
PHP suite against native PHP and MySQL for exactly this reason.

## Known differences from MySQL

- `DECIMAL` is stored as `TEXT` to preserve exact money values; SQLite has no
  fixed-point type and `REAL` would introduce float error.
- `SELECT ... FOR UPDATE` is accepted and ignored — SQLite serialises writes.
- `ALTER TABLE ... ADD CONSTRAINT FOREIGN KEY` is recorded but not enforced;
  SQLite cannot add a foreign key to an existing table.
- Multi-statement `COM_QUERY` is supported; prepared-statement protocol
  (`COM_STMT_PREPARE`) is not — the CI3 drivers do not use it.
- `SUM()` over a DECIMAL column comes back from SQLite as a float, so the
  column is advertised as NEWDECIMAL (not LONGLONG) and the client keeps the
  fraction. Advertising it as an integer — which this server used to do —
  silently truncated every money aggregate in development while real MySQL
  returned it correctly.
